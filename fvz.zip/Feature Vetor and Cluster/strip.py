import os
import sys

fo = open("variant1a.asm", "w") 

with open("variant1.asm") as fi:
    for line in fi:
        line = line.partition(';')[0]
        print(line)
        fo.write(line + os.linesep)
