

from __future__ import print_function


from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import Normalizer
from sklearn.cluster import KMeans, MiniBatchKMeans
from argparse import ArgumentParser
import sys


parser = ArgumentParser()
parser.add_argument("--file", dest="filename", type=str, help="Enter a filename to process.")
args = parser.parse_args()

print(args.filename)
NumberOfClusters = 50
NumberOfFeatures = 10000
FileName         = args.filename

print("Extracting feature vectors.")

vectorizer = TfidfVectorizer(max_df=0.5, max_features=NumberOfFeatures, min_df=2, stop_words='english', use_idf="true")

raw_data = open(FileName)
#vectorizer = CountVectorizer()
X = vectorizer.fit_transform(raw_data)
print(X.toarray())

print("n_samples: %d, n_features: %d" % X.shape)
print()

#Cluster

km = KMeans(n_clusters=NumberOfClusters, init='k-means++', max_iter=16, n_init=1, verbose="true")

print("Clustering data with %s" % km)

km.fit(X)

print()

print("Top tokens by cluster:")
  
order_centroids = km.cluster_centers_.argsort()[:, ::-1]

terms = vectorizer.get_feature_names()
for i in range(NumberOfClusters):
    print("Cluster %d:" % i, end='')
    for ind in order_centroids[i, :10]:
        print(' %s' % terms[ind], end='')
    print()