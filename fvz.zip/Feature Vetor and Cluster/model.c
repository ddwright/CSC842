//Model program for featcure vectoring and clustering

#include <stdio.h>


int main(void)
{
    printf("This is a test");

    return 0;
}
