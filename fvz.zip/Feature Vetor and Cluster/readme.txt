OK, here is what I have so far.

model.c, model.exe - the model program, compiled and linked with default options
variant1.exe - same program as model compiled with /MTd for debug options
model.asm and variant1a.asm decompiled versions

model.txt, variant1a.txt is the execution of the feature vector and clustering program

Miscellanous ramblings,

After I decompiled model I saw that the decompiler added comments, I removed them manually.  
I then decompiled variant1 and I didnt want to remove that many comments so I wrote strip.py to remove them variant1a.asm is the comment removed version.

Optimizing, making fast or small executable made no difference.  I figured the program was too small and simple for any of that to matter. Debug option added a lot of stuff though ;)

After that I ran the .asm's through bow.py ( bag of words heh ).  bow generated feature vectors and clusters.
There are a lot of alogrithims and options for those but I went with this one for now as it was a proof of concept anyway.
I didnt do dimensionality reduction as it was not mentioned, actually just feature vectors were at this point.



