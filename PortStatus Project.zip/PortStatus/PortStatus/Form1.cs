﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Net.NetworkInformation;



namespace PortStatus
{

    public partial class ActivePorts : Form
    {

        IPGlobalProperties ipGlobalProperties = IPGlobalProperties.GetIPGlobalProperties();
        TcpConnectionInformation[] tcpConnInfoArray;
        IPEndPoint[] endPoints;
        IPHostEntry host;
        string saddress;
        string hostname;

        public ActivePorts()
        {

            InitializeComponent();
            LoadListBox();

        }

        private void LoadListBox()
        { 

            tcpConnInfoArray = ipGlobalProperties.GetActiveTcpConnections();
            endPoints = ipGlobalProperties.GetActiveUdpListeners();

            foreach (TcpConnectionInformation tcpi in tcpConnInfoArray)
            {
                saddress = tcpi.RemoteEndPoint.ToString();
        
                saddress = saddress.Substring(0, saddress .LastIndexOf(":"));
                try
                {

                    //                   host = Dns.GetHostEntry(saddress);
                    //                    hostname = host.HostName.ToString();
                    hostname = "test";

                }
                catch
                {
                    hostname = "Unknown";
                }
             
                PortData.Items.Add("TCP    " + "Port:" + tcpi.LocalEndPoint.Port.ToString().PadRight(8) + tcpi.RemoteEndPoint.ToString().PadRight(20) + hostname.PadRight(60) + tcpi.State.ToString());
            }

            foreach (IPEndPoint e in endPoints)
            {
                PortData.Items.Add("UDP   " + e.ToString());
            }       

        }


        private void PortData_SelectedIndexChanged(object sender, EventArgs e)
        {
            int iIndex = tcpConnInfoArray.Length - 1;

            if (PortData.SelectedIndex > iIndex)
                MessageBox.Show(endPoints[PortData.SelectedIndex - tcpConnInfoArray.Length].ToString());
            else
            {
                saddress = tcpConnInfoArray[PortData.SelectedIndex].RemoteEndPoint.ToString();

                saddress = saddress.Substring(0, saddress.LastIndexOf(":"));
                try
                {

                    host = Dns.GetHostEntry(saddress);
                    hostname = host.HostName.ToString();

                    Clipboard.SetText(hostname);
                    try
                    {
                        string[] sSplitHostName = hostname.Split('.');
                        hostname = sSplitHostName[sSplitHostName.Length - 2] + '.' + sSplitHostName[sSplitHostName.Length - 1];
                        TcpClient tcpWhois = new TcpClient("whois.verisign-grs.com", 43);
                        NetworkStream nsWhois = tcpWhois.GetStream();
                        BufferedStream bsWhois = new BufferedStream(nsWhois);
                        StreamWriter swSend = new StreamWriter(bsWhois);
                        StreamReader swRecieve;

                        swSend.WriteLine(hostname);
                        swSend.Flush();
                        this.textBox1.Clear();

                        try
                        {
                            swRecieve = new StreamReader(bsWhois);

                            string sresponse;
                            while ((sresponse = swRecieve.ReadLine()) != null)
                            {
                                this.textBox1.Text += sresponse + "\r\n";
                            }

                        }
                        catch
                        {
                            MessageBox.Show("Whois Server Error", "Error");
                        }

                        finally
                        {
                            try
                            {
                                tcpWhois.Close();
                            }
                            catch
                            {
                            }
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Error connecting to server", "Error");
                    }                                                    

                }
                catch
                {
                    hostname = "Unknown";
                    Clipboard.SetText(saddress);
                }

                this.textBox1.Show();
            }
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.textBox1.Hide();
            this.textBox1.Clear();
            PortData.Items.Clear();
            LoadListBox();
        }
    }
}
